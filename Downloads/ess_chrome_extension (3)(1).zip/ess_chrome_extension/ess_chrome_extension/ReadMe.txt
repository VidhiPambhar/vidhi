1.Open Google Chrome
2.Open extensions tab from menu or open this url "chrome://extensions/" (without quots).
3.Enable Developer mode using the toggle button at top right corner.
4.Click on "Load unpacked" button and choose the folder where you have extract the files.
5.That's it. Now open https://ess.infibeam-inc.ooo/COSEC/ESSIndex.aspx.

Have a good day. :)
